Simple LED blink demo (STM32L052).

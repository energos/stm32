Ken Boak's STM32F746VG Break-Out-Board, see

<http://sustburbia.blogspot.nl/2015/07/at-last-stm32f7xx-216mhz-arm-cortex-m7.html>

Files for the STM32F103ZE "Basic board w/ µSD and two 2x32-pin headers

* <https://www.aliexpress.com/item/x/32720494327.html>

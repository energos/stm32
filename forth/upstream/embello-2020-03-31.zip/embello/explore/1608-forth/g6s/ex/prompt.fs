\ try out a custom prompt

<<<core>>>
compiletoflash
include ../../flib/mecrisp/prompt.fs

These files are for the Blue Pill and similar boards, running on serial USART1.

The pin definitions for up to 64-pin chips (Tx, Cx, and Rx) are included.

Definitions for LED and other board-specific pins must be added on top of this.

The `core.fs` file only includes OLED + graphics and multi-tasker support.

forgetram

led-init
sd-mount.
ls

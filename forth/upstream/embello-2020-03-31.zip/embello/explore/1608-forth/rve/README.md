These files are for an STM32F103VE board from eBay, with µSD socket and EEPROM.
The µSD card is connected to the SDIO pins. The LED is on pin PB9.

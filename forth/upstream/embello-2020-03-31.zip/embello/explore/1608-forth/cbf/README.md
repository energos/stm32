The "Core Board Four" from Haoyu, with STM32F407ZG and lots of RAM + flash.

There's an LED on PF6.

Available at <http://www.hotmcu.com/hystm32f4xxcore144-coredev-board-p-10.html>

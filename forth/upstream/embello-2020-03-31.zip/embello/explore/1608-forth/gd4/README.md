Setup for the RedDragon407 board - work in progress...

No longer available: <http://www.ebay.com/itm/321266868395>

Possible alternative (more features): <http://www.ebay.com/itm/221527811264>

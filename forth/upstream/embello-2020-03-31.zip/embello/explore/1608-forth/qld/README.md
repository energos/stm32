This is a Blue Pill, connected to a JeeNode Zero with DTR, RTS and 4x SPI.
The purpose is to measure the performance of re-flashing over SPI iso USART.

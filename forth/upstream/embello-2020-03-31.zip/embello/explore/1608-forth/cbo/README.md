The "Core Board One" from Haoyu, with STM32F103ZE and lots of RAM + flash.

There's an LED on PF6.

The USB enable is on PF10, D+ is pulled up when "0".

Available at <http://www.hotmcu.com/hystm32f1xxcore144-coredev-board-p-2.html>

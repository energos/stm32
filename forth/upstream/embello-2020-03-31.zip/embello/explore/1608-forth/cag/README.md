These files are for the Blue Pill and similar boards, running on serial USART1.

This is work in progress for a console access gateway to a remote node over RF.

The "Multi-Receiver Node" is based on this dime-a-dozen STM32F103C8 board:

<http://www.aliexpress.com/item/1pcs-STM32F103C8T6-ARM-STM32-Minimum-System-Development-Board-Module-For-arduino/32583160323.html>

LED is on PC13.

* **RFM69** - NSS: PA4, SCLK: PA5, MISO: PA6, MOSI: PA7

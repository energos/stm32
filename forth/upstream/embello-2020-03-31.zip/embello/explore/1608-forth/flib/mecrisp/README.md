The files in this directory were copied and some were slightly modified from
the examples found in the [Mecrisp Stellaris Forth][MSF] source code.

These files are covered by the [GNU General Public License][GPL], version 3.

  [MSF]: http://mecrisp.sourceforge.net
  [GPL]: https://en.wikipedia.org/wiki/GNU_General_Public_License

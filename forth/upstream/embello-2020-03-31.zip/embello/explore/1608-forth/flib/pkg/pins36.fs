\ pin definitions for chips up to 36 pins

0 0  io constant PA0      1 0  io constant PB0      3 0  io constant PD0
0 1  io constant PA1      1 1  io constant PB1      3 1  io constant PD1
0 2  io constant PA2      1 2  io constant PB2
0 3  io constant PA3      1 3  io constant PB3
0 4  io constant PA4      1 4  io constant PB4
0 5  io constant PA5      1 5  io constant PB5
0 6  io constant PA6      1 6  io constant PB6
0 7  io constant PA7      1 7  io constant PB7
0 8  io constant PA8
0 9  io constant PA9
0 10 io constant PA10
0 11 io constant PA11
0 12 io constant PA12
0 13 io constant PA13
0 14 io constant PA14
0 15 io constant PA15

Board definition for the "ARMinARM" add-on board for Raspberry Pi.

Available from [OnAndOffables][OAO]

* STM32F103RE, 512K flash, 64K RAM, 64-pin package

  [OAO]: http://www.onandoffables.com/index.php?m=arminarm

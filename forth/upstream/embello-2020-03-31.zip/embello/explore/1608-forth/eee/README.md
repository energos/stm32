Experimental Engine Explorations on a HyTiny

LEDs:

    D1 = PA12
    D2 = PA11
    D3 = PA10 (RX)
    D4 = PA9  (TX)
    D5 = PA8
    D6 = PB2

Buttons:

    K1 = PB5
    K2 = PB4
    K3 = PB3
    P4 = PA15

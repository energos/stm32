\ core definitions

\ <<<board>>>
compiletoflash
( core start: ) here hex.

include ../flib/mecrisp/quotation.fs
include ../flib/mecrisp/multi.fs
include ../flib/any/timed.fs

cornerstone <<<core>>>
hello

\ test long input lines, i.e. more than one 64-byte USB packet

PA1 ioc!  OMODE-PP PA1 io-mode!  PA1 ios!  2 ms

1234567890-abcdefghijklmnopqrstuvwxyz+ABCDEFGHIJKLMNOPQRSTUVWXYZ=0987654321/zyxwvutsrqpomnlkjihgfedcba.ZYXWVUTSRQPOMNLKJIHGFEDCBA?1234567890?11223344556677889900

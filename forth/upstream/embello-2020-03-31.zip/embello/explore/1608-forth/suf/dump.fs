\ incude this to dump the loaded image as Intel hex code

compiletoram
include ../flib/mecrisp/hexdump.fs
hexdump

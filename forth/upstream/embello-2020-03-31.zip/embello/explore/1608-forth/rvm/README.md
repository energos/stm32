Remote Voltmeter, based on a JNZ rev1 prototype and the Analog Plug.

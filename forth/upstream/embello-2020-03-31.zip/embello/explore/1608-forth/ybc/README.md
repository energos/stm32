Board definition for the "Yellow Blue stm32f103rC" board.

Available on [AliExpress][A] - probably the same as [this][B] and [this][C].

* STM32F103RC, 256K flash, 48K RAM, 64-pin package

  [A]: http://www.aliexpress.com/item/Cortex-M3-32-bit-RISC-STM32F103RCT6-development-board-USB-STM32F103RCT6-board-JTAG-SWD-free-shipping/32333836792.html
  [B]: http://www.aliexpress.com/item/STM32F103RCT6-development-board-Cortex-M3-32-bit-RISC-USB-STM32F103RCT6-JTAG-SWD-Program-learning-board-STM32/32451683720.html
  [C]: http://www.aliexpress.com/item/STM32-Cortex-development-board-minimum-system-board-M3-STM32F103RCT6-RBT6-ARM-development-board/32352723456.html

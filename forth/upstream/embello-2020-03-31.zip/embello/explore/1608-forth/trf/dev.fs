\ Tiny RF node

forgetram

6 rf.group !
8686 rf.freq !
rf-listen

WaveShare Port103Z board with STM32F103ZE in 144-pin package.

All pins broken out on 0.1" male headers, 3+5 buttons, 4 LEDs, RTC crystal.

Available from [WaveShare][WS].

  [WS]: http://www.waveshare.com/product/mcu-tools/stm32/evk-port/port103z.htm

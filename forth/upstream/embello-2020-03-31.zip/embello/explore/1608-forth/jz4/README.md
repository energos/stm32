This code runs on the JeeNode Zero revision 4.

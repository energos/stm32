\ RF console interface, client side

forgetram

870 rf.freq !

5432 .
5432 rf-txtest

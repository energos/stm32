These files are for an STM32F103VE with TM1638-based 7-seg LEDs + 4x4 keyboard.
The µSD card is connected to the SDIO pins. The LED is on pin PB9.

This code runs on the JeeNode Zero prototype board - **revision 1 !**

The board is attached to a LED Node v2a, without the ATmega and RFM12:

    PA0 = red
    PA1 = green
    PA2 = blue

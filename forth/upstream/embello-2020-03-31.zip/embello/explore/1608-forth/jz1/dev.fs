\ development code

<<<core>>>

include main.fs

( ram free: ) flashvar-here here - .
main

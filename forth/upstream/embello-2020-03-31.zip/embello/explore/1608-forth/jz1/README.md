This code runs on the JeeNode Zero prototype board - **revision 1 !**

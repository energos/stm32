\ development code

<<<core>>>

include main.fs

( ram free: ) flashvar-here here - .
1234 ms main

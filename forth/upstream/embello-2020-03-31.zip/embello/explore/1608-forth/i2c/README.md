Test setup for I2C devices and driver development, using JeeNode Zero prototype.

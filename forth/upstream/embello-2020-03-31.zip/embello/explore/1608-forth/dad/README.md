The "Dime-A-Dozen" boards from eBay and AliExpress, all with an STM32F103C8.

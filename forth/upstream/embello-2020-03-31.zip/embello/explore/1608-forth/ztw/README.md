This is the "Zero To Wireless" demo setup, as described on the JeeLabs weblog:

* <http://jeelabs.org/2016/03/from-zero-to-wireless/>

Note that [Mecrisp Forth](http://mecrisp.sourceforge.net) is GPL3-licensed, and so are the hex files in this area.

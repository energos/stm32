forgetram

clear
: a 100 0 do i i 2* putpixel loop ;
a

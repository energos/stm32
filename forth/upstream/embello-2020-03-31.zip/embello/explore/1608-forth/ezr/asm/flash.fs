  $01 w $f5 w $00 w $3e w $b6 w $ed w $79 w $3e w $49 w $ed w $79 w $0e w
  $f9 w $3e w $29 w $ed w $79 w $0e w $f5 w $3e w $b6 w $ed w $79 w $3e w
  $49 w $ed w $79 w $0e w $fa w $3e w $00 w $ed w $79 w $0e w $ff w $3e w
  $01 w $ed w $79 w $18 w $fe w

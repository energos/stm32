  $06 w $00 w $0e w $a5 w $3e w $03 w $ed w $79 w $0e w $c3 w $3e w $80 w
  $ed w $79 w $0e w $c0 w $3e w $1a w $ed w $79 w $0e w $c3 w $3e w $03 w
  $ed w $79 w $0e w $c2 w $3e w $06 w $ed w $79 w $21 w $39 w $01 w $7e w
  $a7 w $28 w $10 w $0e w $c5 w $ed w $78 w $e6 w $20 w $28 w $f8 w $0e w
  $c0 w $7e w $ed w $79 w $23 w $18 w $ec w $18 w $fe w $48 w $65 w $6c w
  $6c w $6f w $20 w $57 w $6f w $72 w $6c w $64 w $21 w $0a w $0d w $00 w

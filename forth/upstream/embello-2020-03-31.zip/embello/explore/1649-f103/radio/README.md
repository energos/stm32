Demo application with RF69 wireless radio.

The RFM69 module must be connected as follows:

    PA4 = SSEL
    PA5 = SCLK
    PA6 = MISO
    PA7 = MOSI

As well as +3.3V power, ground, and a wire antenna of about 83 mm (for 868 MHz).

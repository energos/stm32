Control an LED over the serial port (STM32F103).

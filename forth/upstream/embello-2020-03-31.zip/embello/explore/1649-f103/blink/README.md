Simple LED blink demo (STM32F103).

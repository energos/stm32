Embedded software from JeeLabs
==============================

Quick Links
-----------

* [Forth-based JeeLabs JeeNodes Zero](./explore/1608-forth)

Acknowledgments
---------------

With many thanks for the inspiring discussions and code contributions by:

* James Churchill
* Thorsten von Eicken
* Martyn Judd
* Matthias Koch
* Thomas Lohmüller
* John O'Hare
* Joris Pragt
* Frank (SevenW)
* Matthias Urlichs

-- [jcw](http://jeelabs.org/about/)

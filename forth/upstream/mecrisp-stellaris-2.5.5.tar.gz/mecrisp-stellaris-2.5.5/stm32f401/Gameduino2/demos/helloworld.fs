: helloworld
    GD.init

    $103000 GD.ClearColorRGB#
    GD.Clear
    240 136 31 GD.OPT_CENTER s" Hello world" GD.cmd_text
    GD.swap
;

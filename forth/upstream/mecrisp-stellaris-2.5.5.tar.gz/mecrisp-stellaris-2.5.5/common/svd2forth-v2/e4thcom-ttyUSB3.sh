#!/bin/sh
e4thcom -t mecrisp-st -d ttyUSB3 -b B115200	| tee e4thcom.log

#Digital-to-Analog Converter (DAC) examples

simple-msk-tx.txt - MSK modulation using simple numbers only. No complex I/Q needed.

sine-wave.txt     - Generate a sine wave.

square-wave.txt   - Generate a square wave given a counted string.

triangle-wave.txt - Generate a square wave given a counted string.


#todo
Eventually these examples would be useful for software defined radio.

sawtooth-wave.txt

simple-msk-rx.txt - recieve bitstream from msk modulated signal.

pll.txt           - Phase-Locked Loop

psk31.txt         - Ham radio text chat.
